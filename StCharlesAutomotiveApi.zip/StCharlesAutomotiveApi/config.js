const dotenv = require('dotenv');
dotenv.config();
module.exports = {
  mongodb: process.env.API_URL,
  masterKey: process.env.API_KEY,
  port: process.env.PORT
};